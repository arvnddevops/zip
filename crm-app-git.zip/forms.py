from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, SelectField, SubmitField, PasswordField
from wtforms.validators import DataRequired

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class CustomerForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    phone = StringField("Phone", validators=[DataRequired()])
    address = StringField("Address")
    submit = SubmitField("Save")

class OrderForm(FlaskForm):
    customer_id = SelectField("Customer", coerce=int, validators=[DataRequired()])
    amount = FloatField("Amount", validators=[DataRequired()])
    payment_status = SelectField("Payment Status", choices=[("Paid","Paid"),("Pending","Pending")])
    payment_mode = SelectField("Payment Mode", choices=[("Cash","Cash"),("UPI","UPI"),("Card","Card")])
    delivery_status = SelectField("Delivery Status", choices=[("Delivered","Delivered"),("Not Delivered","Not Delivered")])
    submit = SubmitField("Save")