#!/bin/bash
cd /home/ec2-user/crm-app
source venv/bin/activate
gunicorn -w 3 -b 127.0.0.1:5000 app:app
