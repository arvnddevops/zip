#!/bin/bash
set -e
echo "=== CRM APP SETUP START ==="
sudo yum update -y || sudo apt-get update -y || true
# Install python & nginx (Amazon Linux or Ubuntu)
if command -v yum >/dev/null 2>&1; then
  sudo yum install -y python3 python3-venv nginx git
else
  sudo apt-get install -y python3 python3-venv python3-pip nginx git
fi

cd "$(dirname "$0")"
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

mkdir -p instance
touch instance/crm.db
chmod +x run_gunicorn.sh backup_db.sh

# systemd
if [ -d "/etc/systemd/system" ]; then
  sudo cp systemd/crm.service /etc/systemd/system/crm.service
  sudo systemctl daemon-reload
  sudo systemctl enable crm --now
fi

# nginx
if [ -d "/etc/nginx" ]; then
  sudo cp nginx/crm.conf /etc/nginx/conf.d/crm.conf || sudo cp nginx/crm.conf /etc/nginx/sites-available/crm.conf || true
  if [ -d /etc/nginx/sites-enabled ]; then
    sudo ln -sf /etc/nginx/sites-available/crm.conf /etc/nginx/sites-enabled/crm.conf || true
  fi
  sudo nginx -t && sudo systemctl restart nginx
fi

echo "=== CRM APP SETUP COMPLETE ==="
echo "Login: admin / admin123" 