from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from forms import CustomerForm, OrderForm, LoginForm
from models import db, Customer, Order
from ensure_columns import ensure_all_columns
from config import Config
import os

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

with app.app_context():
    db.create_all()
    ensure_all_columns()

    admin = os.getenv("ADMIN_USER", "admin")
    password = os.getenv("ADMIN_PASS", "admin123")
    hashed = generate_password_hash(password)

    if not os.path.exists("instance/admin.lock"):
        os.makedirs("instance", exist_ok=True)
        open("instance/admin.lock", "w").close()
        app.logger.info("Admin user created")

@app.before_request
def require_login():
    allowed = ['login']
    if 'user' not in session and request.endpoint not in allowed:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.username.data == "admin" and check_password_hash(
            generate_password_hash("admin123"), form.password.data
        ):
            session['user'] = "admin"
            return redirect(url_for('customers'))
        flash("Invalid credentials", "danger")
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/')
def home():
    return redirect(url_for('customers'))

@app.route('/customers')
def customers():
    data = Customer.query.order_by(Customer.id.desc()).all()
    return render_template('customers.html', data=data)

@app.route('/customers/add', methods=['GET', 'POST'])
def add_customer():
    form = CustomerForm()
    if form.validate_on_submit():
        new = Customer(name=form.name.data, phone=form.phone.data, address=form.address.data)
        db.session.add(new)
        db.session.commit()
        flash("Customer added", "success")
        return redirect(url_for('customers'))
    return render_template('customers.html', form=form, mode="add")

@app.route('/orders')
def orders():
    data = Order.query.order_by(Order.id.desc()).all()
    customers = Customer.query.order_by(Customer.id.desc()).all()
    return render_template('orders.html', data=data, customers=customers)

@app.route('/orders/add', methods=['GET', 'POST'])
def add_order():
    form = OrderForm()
    form.customer_id.choices = [(c.id, c.name) for c in Customer.query.order_by(Customer.id.desc())]
    if form.validate_on_submit():
        order = Order(
            customer_id=form.customer_id.data,
            amount=form.amount.data,
            payment_status=form.payment_status.data,
            payment_mode=form.payment_mode.data if form.payment_status.data == "Paid" else None,
            delivery_status=form.delivery_status.data
        )
        db.session.add(order)
        db.session.commit()
        flash("Order added", "success")
        return redirect(url_for('orders'))
    return render_template('orders.html', form=form, mode="add")