from models import db
from sqlalchemy import inspect

def ensure_all_columns():
    inspector = inspect(db.engine)
    cols = [c["name"] for c in inspector.get_columns("order")]

    required = {
        "payment_status": "ALTER TABLE 'order' ADD COLUMN payment_status VARCHAR(20) DEFAULT 'Pending'",
        "payment_mode": "ALTER TABLE 'order' ADD COLUMN payment_mode VARCHAR(20)",
        "delivery_status": "ALTER TABLE 'order' ADD COLUMN delivery_status VARCHAR(20) DEFAULT 'Not Delivered'"
    }

    for col, query in required.items():
        if col not in cols:
            db.session.execute(query)
            db.session.commit()