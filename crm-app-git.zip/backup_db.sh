#!/bin/bash
mkdir -p backups
cp instance/crm.db backups/crm-$(date +%F-%H%M).db
