from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    address = db.Column(db.Text, nullable=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    amount = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.String(20), nullable=False, default="Pending")
    payment_mode = db.Column(db.String(20), nullable=True)
    delivery_status = db.Column(db.String(20), nullable=False, default="Not Delivered")

    customer = db.relationship('Customer', backref='orders')