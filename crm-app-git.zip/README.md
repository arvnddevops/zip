# Flask CRM App

SQLite + EC2 + Gunicorn + Nginx + Bootstrap UI

## Quick Start
```bash
unzip crm-app-git.zip
cd crm-app
bash setup.sh
```
App URL: `http://<server-ip>`  
Login: `admin / admin123`

## Service
```bash
sudo systemctl status crm
sudo systemctl restart crm
journalctl -u crm -f
```