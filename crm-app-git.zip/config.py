class Config:
    SECRET_KEY = "crmsecret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///instance/crm.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False